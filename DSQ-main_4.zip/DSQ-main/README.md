# DSQ
 Practical for Data Structures and Algorithms
